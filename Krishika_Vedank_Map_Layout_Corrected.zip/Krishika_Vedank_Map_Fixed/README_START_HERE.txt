Krishika & Vedank wedding website

1. Extract the entire ZIP first.
2. Open index.html in Chrome or Edge.
3. Keep style.css, script.js and assets folder together.
4. Beige screen appears immediately when the wooden gate opens.
5. Each event has date/day and a map icon. Map links remain disabled until venues are supplied.
6. Edit venueDetails in script.js for each event.
7. The supplied music is in assets/music.mpeg. Click gate or music button to start playback.

Files are provided as a reference-based recreation, not an exact source copy.
